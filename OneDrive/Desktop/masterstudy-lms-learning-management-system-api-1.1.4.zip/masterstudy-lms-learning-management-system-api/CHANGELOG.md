## 1.1.4
- Course announcement empty fixed
- Added permission callback to several routes

## 1.1.3
- User plans fixed
- Plans route fixed when PMPro disabled

## 1.1.2
- User courses cache hash added 
- Restore password route added

## 1.1.1
- Verify purchase option added to switch between live/sandbox

## 1.1.0
- Verify purchase endpoint added

## 1.0.1
- Empty addons list bug fixed
- Event on quiz completion added

## 1.0.0
- Release.
