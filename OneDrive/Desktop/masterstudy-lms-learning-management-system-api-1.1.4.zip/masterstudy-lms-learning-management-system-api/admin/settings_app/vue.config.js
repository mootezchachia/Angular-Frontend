module.exports = {
    filenameHashing: false,
    productionSourceMap: false,
    publicPath: "",
    devServer: {
        proxy: 'http://lms.loc/',
    }
};