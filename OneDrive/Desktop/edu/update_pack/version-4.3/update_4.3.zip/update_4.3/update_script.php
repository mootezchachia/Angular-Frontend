<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

// ADD NEW COLUMN INSINDE payment TABLE
$user_image_column = array(
	'image' => array(
		'type' => 'VARCHAR',
		'constraint' => 255,
		'default' => null,
		'null' => TRUE
	)
);
$CI->dbforge->add_column('users', $user_image_column);


$frontend_settings_data1['key'] = 'banner_image';
$frontend_settings_data1['value'] = 'home-banner.jpg';
$CI->db->insert('frontend_settings', $frontend_settings_data1);

$frontend_settings_data2['key'] = 'light_logo';
$frontend_settings_data2['value'] = 'logo-light.png';
$CI->db->insert('frontend_settings', $frontend_settings_data2);

$frontend_settings_data3['key'] = 'dark_logo';
$frontend_settings_data3['value'] = 'logo-dark.png';
$CI->db->insert('frontend_settings', $frontend_settings_data3);

$frontend_settings_data4['key'] = 'small_logo';
$frontend_settings_data4['value'] = 'logo-light-sm.png';
$CI->db->insert('frontend_settings', $frontend_settings_data4);

$frontend_settings_data5['key'] = 'favicon';
$frontend_settings_data5['value'] = 'favicon.png';
$CI->db->insert('frontend_settings', $frontend_settings_data5);


// INSERT VERSION NUMBER INSIDE SETTINGS TABLE
$settings_data = array( 'value' => '4.3');
$CI->db->where('key', 'version');
$CI->db->update('settings', $settings_data);
?>
